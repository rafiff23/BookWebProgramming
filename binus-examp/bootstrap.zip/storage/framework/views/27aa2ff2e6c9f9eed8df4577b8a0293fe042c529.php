<?php $__env->startSection('content'); ?>

    <div class="book-list">

        <?php if(!empty($category)): ?>
            <h5>Category : <?php echo e($category); ?></h5>
        <?php endif; ?>
        
        <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <div class="img-wrapper">
                <div class="overlay">
                    <a href="/detail/<?php echo e($book->id); ?>">detail</a>
                </div>
                
                <div class="img" style="background-image: url('./assets/image.jpg')" ></div>
            </div>
            <p class="title"><?php echo e($book->title); ?></p>
            <p class="author">By <?php echo e($book->author); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>      

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmat-riyadi/Random/laravel/binus-examp/resources/views/index.blade.php ENDPATH**/ ?>