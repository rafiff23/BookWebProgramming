<?php $__env->startSection('content'); ?>

    <div class="publisher-container">
        <div class="about">
            <div style="background-image: url('<?php echo e(asset('storage/'.$publisher->image)); ?>')" class="publisher-logo"></div>
            <div class="about-group">
                <p class="small">Name</p>
                <p class="data"><?php echo e($publisher->name); ?></p>
                <p class="small">Address</p>
                <p class="data"><?php echo e($publisher->address); ?></p>
                <p class="small">Phone</p>
                <p class="data"><?php echo e($publisher->phone); ?></p>
                <p class="small">Email</p>
                <p class="data"><?php echo e($publisher->email); ?></p>
            </div>
        </div>
        <div class="gallery">
            <?php $__currentLoopData = $publisher->book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="img-wrapper">
                    <div class="overlay">
                        <a href="/detail/<?php echo e($book->id); ?>" >detail</a>
                    </div>
                    <p class="badges">UI/UX</p>
                    <div class="img" style="background-image: url('<?php echo e(asset('storage/'.$book->image)); ?>')" ></div>
                </div>
                <p class="title"><?php echo e($book->title); ?></p>
                <p class="author"><?php echo e($book->author); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmat-riyadi/Random/laravel/binus-examp/resources/views/publisher-detail.blade.php ENDPATH**/ ?>