<?php $__env->startSection('content'); ?>
    <div class="detail-container">
        <div class="img" style="background-image: url('<?php echo e(asset('storage/'. $book->image)); ?>');" ></div>
        <div class="detail-content">
            <p class="author">By <?php echo e($book->author); ?> | <?php echo e($book->year); ?></p>
            <h3 class="title"><?php echo e($book->title); ?></h3>
            <p class="description"><?php echo e($book->synopsis); ?></p>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmat-riyadi/Random/laravel/binus-examp/resources/views/detail.blade.php ENDPATH**/ ?>