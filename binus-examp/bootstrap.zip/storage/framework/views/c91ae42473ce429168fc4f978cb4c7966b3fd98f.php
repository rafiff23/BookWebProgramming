<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Binus - Examp</title>

    
    <link rel="stylesheet" href="<?php echo e(asset('assets/style.css')); ?>">

    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet">

</head>
<body>

    <nav class="nav" >
        <h4 class="logo">
            Book.com
        </h4>
        <div class="group-link">
            <a class="nav-link" href="/">Home</a>
            <div href="" class="nav-link">
                Category
                <ul class="pop-up">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="/category/<?php echo e($item->id); ?>"><?php echo e($item->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <a class="nav-link" href="/publisher">Publisher</a>
            <a class="nav-link" href="/contact">Contact</a>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>
    
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
</body>
</html><?php /**PATH /Users/rahmat-riyadi/Random/laravel/binus-examp/resources/views/app.blade.php ENDPATH**/ ?>