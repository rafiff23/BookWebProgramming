<?php $__env->startSection('content'); ?>
    
    <table cell-padding="0" >
        <thead>
            <th>#</th>
            <th>Name</th>
            <th>Address</th>
            <th>Action</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $publishers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td><?php echo e($item->name); ?></td>
                    <td><?php echo e($item->address); ?></td>
                    <td>
                        <a href="/publisher/detail/<?php echo e($item->id); ?>" class="detail-publisher">
                            Detail
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmat-riyadi/Random/laravel/binus-examp/resources/views/publisher.blade.php ENDPATH**/ ?>