<?php $__env->startSection('content'); ?>

    <h4 class="cat" >Category : <?php echo e($category->name); ?></h4>

    <div class="book-list">
        <?php $__currentLoopData = $category->book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card">
            <div class="img-wrapper">
                <div class="overlay">
                    <a href="/detail/<?php echo e($book->id); ?>">detail</a>
                </div>
                
                <div class="img" style="background-image: url('<?php echo e(asset('storage/'. $book->image)); ?>')" ></div>
            </div>
            <p class="title"><?php echo e($book->title); ?></p>
            <p class="author">By <?php echo e($book->author); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmat-riyadi/Random/laravel/binus-examp/resources/views/category.blade.php ENDPATH**/ ?>